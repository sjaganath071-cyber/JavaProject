package com.team11.defense_logistics.service;

import com.team11.defense_logistics.dto.AssetDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.List;

@Service
public class AssetService {

    private final RestClient restClient;
    private final String assetApiUrl;

    public AssetService(
            RestClient.Builder restClientBuilder,
            @Value("${services.asset.base-url:http://localhost:8082/api/v1/assets}")
            String assetApiUrl) {

        this.restClient = restClientBuilder.build();
        this.assetApiUrl = assetApiUrl;
    }

    public List<AssetDto> getAllAssets() {
        try {
            List<AssetDto> assets = restClient.get()
                    .uri(assetApiUrl)
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<AssetDto>>() {});

            return assets == null ? new ArrayList<>() : assets;

        } catch (RestClientException exception) {
            throw new AssetServiceException(
                    "Unable to retrieve assets from the backend service.",
                    exception
            );
        }
    }

    public AssetDto getAssetById(Long id) {
        try {
            AssetDto asset = restClient.get()
                    .uri(assetApiUrl + "/{id}", id)
                    .retrieve()
                    .body(AssetDto.class);

            if (asset == null) {
                throw new AssetServiceException(
                        "The backend returned no asset record."
                );
            }

            return asset;

        } catch (RestClientException exception) {
            throw new AssetServiceException(
                    "Unable to retrieve asset record " + id + ".",
                    exception
            );
        }
    }

    public AssetDto createAsset(AssetDto asset) {
        try {
            AssetDto created = restClient.post()
                    .uri(assetApiUrl)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(asset)
                    .retrieve()
                    .body(AssetDto.class);

            if (created == null) {
                throw new AssetServiceException(
                        "The backend returned no created asset record."
                );
            }

            return created;

        } catch (RestClientException exception) {
            throw new AssetServiceException(
                    "Unable to create the asset. Check the submitted information.",
                    exception
            );
        }
    }

    public AssetDto updateAsset(Long id, AssetDto asset) {
        try {
            AssetDto updated = restClient.put()
                    .uri(assetApiUrl + "/{id}", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(asset)
                    .retrieve()
                    .body(AssetDto.class);

            if (updated == null) {
                throw new AssetServiceException(
                        "The backend returned no updated asset record."
                );
            }

            return updated;

        } catch (RestClientException exception) {
            throw new AssetServiceException(
                    "Unable to update asset record " + id + ".",
                    exception
            );
        }
    }

    public static class AssetServiceException extends RuntimeException {

        public AssetServiceException(String message) {
            super(message);
        }

        public AssetServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
