package com.team11.defense_logistics.service;

import com.team11.defense_logistics.dto.MaintenanceDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.Collections;
import java.util.List;

@Service
public class MaintenanceService {

    private final RestClient restClient;

    public MaintenanceService(
            RestClient.Builder restClientBuilder,
            @Value("${maintenance.api.base-url:http://localhost:8085/api/v1/maintenance}")
            String baseUrl) {

        this.restClient = restClientBuilder
                .baseUrl(baseUrl)
                .build();
    }

    public List<MaintenanceDto> getAllRecords() {
        try {
            List<MaintenanceDto> records = restClient.get()
                    .uri("")
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<MaintenanceDto>>() {
                    });

            return records != null ? records : Collections.emptyList();

        } catch (RestClientException exception) {
            throw new MaintenanceServiceException(
                    "Unable to retrieve maintenance records. Check the maintenance backend.",
                    exception
            );
        }
    }

    public MaintenanceDto getRecordById(Long id) {
        try {
            MaintenanceDto record = restClient.get()
                    .uri("/{id}", id)
                    .retrieve()
                    .body(MaintenanceDto.class);

            if (record == null) {
                throw new MaintenanceServiceException(
                        "Maintenance record was not found."
                );
            }

            return record;

        } catch (RestClientException exception) {
            throw new MaintenanceServiceException(
                    "Unable to retrieve maintenance record with ID " + id + ".",
                    exception
            );
        }
    }

    public MaintenanceDto createRecord(MaintenanceDto record) {
        try {
            MaintenanceDto createdRecord = restClient.post()
                    .uri("")
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(record)
                    .retrieve()
                    .body(MaintenanceDto.class);

            if (createdRecord == null) {
                throw new MaintenanceServiceException(
                        "The maintenance backend returned an empty response."
                );
            }

            return createdRecord;

        } catch (RestClientException exception) {
            throw new MaintenanceServiceException(
                    "Unable to create maintenance record. Verify the backend API.",
                    exception
            );
        }
    }

    public MaintenanceDto updateRecord(Long id, MaintenanceDto record) {
        try {
            MaintenanceDto updatedRecord = restClient.put()
                    .uri("/{id}", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(record)
                    .retrieve()
                    .body(MaintenanceDto.class);

            if (updatedRecord == null) {
                throw new MaintenanceServiceException(
                        "The maintenance backend returned an empty response."
                );
            }

            return updatedRecord;

        } catch (RestClientException exception) {
            throw new MaintenanceServiceException(
                    "Unable to update maintenance record with ID " + id + ".",
                    exception
            );
        }
    }

    public static class MaintenanceServiceException extends RuntimeException {

        public MaintenanceServiceException(String message) {
            super(message);
        }

        public MaintenanceServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
