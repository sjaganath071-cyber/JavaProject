package com.team11.defense_logistics.service;

import com.team11.defense_logistics.dto.VehicleDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.List;

@Service
public class VehicleService {

    private final RestClient restClient;
    private final String vehicleApiUrl;

    public VehicleService(
            RestClient.Builder restClientBuilder,
            @Value("${services.vehicle.base-url:http://localhost:8083/api/v1/vehicles}")
            String vehicleApiUrl) {

        this.restClient = restClientBuilder.build();
        this.vehicleApiUrl = vehicleApiUrl;
    }

    public List<VehicleDto> getAllVehicles() {
        try {
            List<VehicleDto> vehicles = restClient.get()
                    .uri(vehicleApiUrl)
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<VehicleDto>>() {});

            return vehicles == null ? new ArrayList<>() : vehicles;

        } catch (RestClientException exception) {
            throw new VehicleServiceException(
                    "Unable to retrieve vehicles from the backend service.",
                    exception
            );
        }
    }

    public VehicleDto getVehicleById(Long id) {
        try {
            VehicleDto vehicle = restClient.get()
                    .uri(vehicleApiUrl + "/{id}", id)
                    .retrieve()
                    .body(VehicleDto.class);

            if (vehicle == null) {
                throw new VehicleServiceException(
                        "The backend returned no vehicle record."
                );
            }

            return vehicle;

        } catch (RestClientException exception) {
            throw new VehicleServiceException(
                    "Unable to retrieve vehicle record " + id + ".",
                    exception
            );
        }
    }

    public VehicleDto createVehicle(VehicleDto vehicle) {
        try {
            VehicleDto created = restClient.post()
                    .uri(vehicleApiUrl)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(vehicle)
                    .retrieve()
                    .body(VehicleDto.class);

            if (created == null) {
                throw new VehicleServiceException(
                        "The backend returned no created vehicle record."
                );
            }

            return created;

        } catch (RestClientException exception) {
            throw new VehicleServiceException(
                    "Unable to register the vehicle.",
                    exception
            );
        }
    }

    public VehicleDto updateVehicle(Long id, VehicleDto vehicle) {
        try {
            VehicleDto updated = restClient.put()
                    .uri(vehicleApiUrl + "/{id}", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(vehicle)
                    .retrieve()
                    .body(VehicleDto.class);

            if (updated == null) {
                throw new VehicleServiceException(
                        "The backend returned no updated vehicle record."
                );
            }

            return updated;

        } catch (RestClientException exception) {
            throw new VehicleServiceException(
                    "Unable to update vehicle record " + id + ".",
                    exception
            );
        }
    }

    public static class VehicleServiceException extends RuntimeException {

        public VehicleServiceException(String message) {
            super(message);
        }

        public VehicleServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
