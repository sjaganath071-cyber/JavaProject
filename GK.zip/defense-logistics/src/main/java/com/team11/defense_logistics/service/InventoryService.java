package com.team11.defense_logistics.service;

import com.team11.defense_logistics.dto.InventoryItemDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.Collections;
import java.util.List;

@Service
public class InventoryService {

    private final RestClient restClient;

    public InventoryService(
            RestClient.Builder restClientBuilder,
            @Value("${inventory.api.base-url:http://localhost:8084/api/v1/inventory}")
            String baseUrl) {

        this.restClient = restClientBuilder
                .baseUrl(baseUrl)
                .build();
    }

    public List<InventoryItemDto> getAllItems() {
        try {
            List<InventoryItemDto> items = restClient.get()
                    .uri("")
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<InventoryItemDto>>() {
                    });

            return items != null ? items : Collections.emptyList();

        } catch (RestClientException exception) {
            throw new InventoryServiceException(
                    "Unable to retrieve inventory. Check whether the inventory backend is running.",
                    exception
            );
        }
    }

    public InventoryItemDto getItemById(Long id) {
        try {
            InventoryItemDto item = restClient.get()
                    .uri("/{id}", id)
                    .retrieve()
                    .body(InventoryItemDto.class);

            if (item == null) {
                throw new InventoryServiceException("Inventory item was not found.");
            }

            return item;

        } catch (RestClientException exception) {
            throw new InventoryServiceException(
                    "Unable to retrieve inventory item with ID " + id + ".",
                    exception
            );
        }
    }

    public InventoryItemDto createItem(InventoryItemDto item) {
        try {
            InventoryItemDto createdItem = restClient.post()
                    .uri("")
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(item)
                    .retrieve()
                    .body(InventoryItemDto.class);

            if (createdItem == null) {
                throw new InventoryServiceException(
                        "The inventory backend returned an empty response."
                );
            }

            return createdItem;

        } catch (RestClientException exception) {
            throw new InventoryServiceException(
                    "Unable to create inventory item. Verify the item code and backend API.",
                    exception
            );
        }
    }

    public InventoryItemDto updateItem(Long id, InventoryItemDto item) {
        try {
            InventoryItemDto updatedItem = restClient.put()
                    .uri("/{id}", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(item)
                    .retrieve()
                    .body(InventoryItemDto.class);

            if (updatedItem == null) {
                throw new InventoryServiceException(
                        "The inventory backend returned an empty response."
                );
            }

            return updatedItem;

        } catch (RestClientException exception) {
            throw new InventoryServiceException(
                    "Unable to update inventory item with ID " + id + ".",
                    exception
            );
        }
    }

    public static class InventoryServiceException extends RuntimeException {

        public InventoryServiceException(String message) {
            super(message);
        }

        public InventoryServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
