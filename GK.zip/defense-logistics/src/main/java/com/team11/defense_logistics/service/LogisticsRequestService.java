package com.team11.defense_logistics.service;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import com.team11.defense_logistics.dto.LogisticsRequestDto;

@Service
public class LogisticsRequestService {

    private final RestClient restClient;

    public LogisticsRequestService(
            RestClient.Builder restClientBuilder,
            @Value("${services.logistics-requests.base-url:http://localhost:8086/api/v1/logistics-requests}")
            String baseUrl) {

        this.restClient = restClientBuilder
                .baseUrl(baseUrl)
                .build();
    }

    public List<LogisticsRequestDto> getAllRequests() {
        try {
            LogisticsRequestDto[] response = restClient.get()
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .body(LogisticsRequestDto[].class);

            if (response == null) {
                return Collections.emptyList();
            }

            return Arrays.asList(response);

        } catch (RestClientException ex) {
            throw new IllegalStateException(
                    "Unable to retrieve logistics requests from the backend.",
                    ex);
        }
    }

    public LogisticsRequestDto getRequestById(Long id) {
        try {
            return restClient.get()
                    .uri("/{id}", id)
                    .accept(MediaType.APPLICATION_JSON)
                    .retrieve()
                    .body(LogisticsRequestDto.class);

        } catch (RestClientException ex) {
            throw new IllegalStateException(
                    "Unable to retrieve logistics request with ID " + id
                            + " from the backend.",
                    ex);
        }
    }

    public LogisticsRequestDto createRequest(LogisticsRequestDto request) {
        try {
            return restClient.post()
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(request)
                    .retrieve()
                    .body(LogisticsRequestDto.class);

        } catch (RestClientException ex) {
            throw new IllegalStateException(
                    "Unable to create logistics request in the backend.",
                    ex);
        }
    }

    public LogisticsRequestDto updateRequest(Long id, LogisticsRequestDto request) {
        try {
            return restClient.put()
                    .uri("/{id}", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .accept(MediaType.APPLICATION_JSON)
                    .body(request)
                    .retrieve()
                    .body(LogisticsRequestDto.class);

        } catch (RestClientException ex) {
            throw new IllegalStateException(
                    "Unable to update logistics request in the backend.",
                    ex);
        }
    }
}
