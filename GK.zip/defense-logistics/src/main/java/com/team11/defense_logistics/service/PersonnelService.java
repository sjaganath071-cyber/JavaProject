package com.team11.defense_logistics.service;

import com.team11.defense_logistics.dto.PersonnelDto;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class PersonnelService {

    private final RestClient restClient;
    private final String personnelApiUrl;

    public PersonnelService(
            RestClient.Builder restClientBuilder,
            @Value("${services.personnel.base-url:http://localhost:8081/api/v1/personnel}")
            String personnelApiUrl) {

        this.restClient = restClientBuilder.build();
        this.personnelApiUrl = personnelApiUrl;
    }

    public List<PersonnelDto> getAllPersonnel() {
        try {
            List<PersonnelDto> personnel = restClient.get()
                    .uri(personnelApiUrl)
                    .retrieve()
                    .body(new ParameterizedTypeReference<List<PersonnelDto>>() {});

            return personnel == null ? new ArrayList<>() : personnel;

        } catch (RestClientException exception) {
            throw new PersonnelServiceException(
                    "Unable to retrieve personnel from the backend service.",
                    exception
            );
        }
    }

    public PersonnelDto getPersonnelById(Long id) {
        try {
            PersonnelDto personnel = restClient.get()
                    .uri(personnelApiUrl + "/{id}", id)
                    .retrieve()
                    .body(PersonnelDto.class);

            if (personnel == null) {
                throw new PersonnelServiceException(
                        "The backend returned no personnel record."
                );
            }

            return personnel;

        } catch (RestClientException exception) {
            throw new PersonnelServiceException(
                    "Unable to retrieve personnel record " + id + ".",
                    exception
            );
        }
    }

    public PersonnelDto createPersonnel(PersonnelDto personnel) {
        try {
            PersonnelDto created = restClient.post()
                    .uri(personnelApiUrl)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(personnel)
                    .retrieve()
                    .body(PersonnelDto.class);

            if (created == null) {
                throw new PersonnelServiceException(
                        "The backend returned no created personnel record."
                );
            }

            return created;

        } catch (RestClientException exception) {
            throw new PersonnelServiceException(
                    "Unable to create personnel. Check the submitted information.",
                    exception
            );
        }
    }

    public PersonnelDto updatePersonnel(Long id, PersonnelDto personnel) {
        try {
            PersonnelDto updated = restClient.put()
                    .uri(personnelApiUrl + "/{id}", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(personnel)
                    .retrieve()
                    .body(PersonnelDto.class);

            if (updated == null) {
                throw new PersonnelServiceException(
                        "The backend returned no updated personnel record."
                );
            }

            return updated;

        } catch (RestClientException exception) {
            throw new PersonnelServiceException(
                    "Unable to update personnel record " + id + ".",
                    exception
            );
        }
    }

    public PersonnelDto updateAvailability(Long id, String availability) {
        try {
            PersonnelDto updated = restClient.patch()
                    .uri(personnelApiUrl + "/{id}/availability", id)
                    .contentType(MediaType.APPLICATION_JSON)
                    .body(Map.of("availability", availability))
                    .retrieve()
                    .body(PersonnelDto.class);

            if (updated == null) {
                throw new PersonnelServiceException(
                        "The backend returned no updated availability record."
                );
            }

            return updated;

        } catch (RestClientException exception) {
            throw new PersonnelServiceException(
                    "Unable to update personnel availability.",
                    exception
            );
        }
    }

    public static class PersonnelServiceException extends RuntimeException {

        public PersonnelServiceException(String message) {
            super(message);
        }

        public PersonnelServiceException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}
