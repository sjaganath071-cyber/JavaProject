package com.team11.defense_logistics.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public class Personnel {

    private Long id;

    @NotBlank(message = "Personnel ID is required")
    private String personnelId;

    @NotBlank(message = "Full name is required")
    private String fullName;

    @NotBlank(message = "Rank or designation is required")
    private String rank;

    @NotBlank(message = "Department or unit is required")
    private String department;

    private String phone;

    @Email(message = "Email must be valid")
    private String email;

    @NotBlank(message = "Status is required")
    @Pattern(regexp = "(?i)^(Active|Inactive)$", message = "Status must be Active or Inactive")
    private String status;

    public Personnel() {
    }

    public Personnel(Long id, String personnelId, String fullName,
                     String rank, String department, String phone,
                     String email, String status) {
        this.id = id;
        this.personnelId = personnelId;
        this.fullName = fullName;
        this.rank = rank;
        this.department = department;
        this.phone = phone;
        this.email = email;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPersonnelId() {
        return personnelId;
    }

    public void setPersonnelId(String personnelId) {
        this.personnelId = personnelId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}