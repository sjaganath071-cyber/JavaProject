
package com.team11.defense_logistics.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

public class Vehicle {

    private Long id;

    @NotBlank(message = "Vehicle number is required")
    private String vehicleNumber;

    @NotBlank(message = "Vehicle type is required")
    private String type;

    @Pattern(regexp = "(?i)^(?:\\s*|Available|Under Maintenance|In Use)$",
            message = "Status must be Available, Under Maintenance, or In Use")
    private String status;

    public Vehicle() {
    }

    public Vehicle(Long id, String vehicleNumber, String type, String status) {
        this.id = id;
        this.vehicleNumber = vehicleNumber;
        this.type = type;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getVehicleNumber() {
        return vehicleNumber;
    }

    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
