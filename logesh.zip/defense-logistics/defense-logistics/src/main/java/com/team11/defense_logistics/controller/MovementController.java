package com.team11.defense_logistics.controller;

import com.team11.defense_logistics.model.Movement;
import com.team11.defense_logistics.service.ResourceAllocationService;
import com.team11.defense_logistics.service.MovementService;
import com.team11.defense_logistics.service.VehicleService;
import jakarta.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/movements")
public class MovementController {
    private final MovementService service;
    private final VehicleService vehicleService;
    private final ResourceAllocationService allocationService;

    public MovementController(
            MovementService service,
            VehicleService vehicleService,
            ResourceAllocationService allocationService) {
        this.service = service;
        this.vehicleService = vehicleService;
        this.allocationService = allocationService;
    }

    @GetMapping
    public String list(Model model) {
        addListData(model);
        model.addAttribute("movement", new Movement());
        return "movements/list";
    }

    @PostMapping
    public String create(
            @Valid @ModelAttribute("movement") Movement movement,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            addListData(model);
            return "movements/list";
        }
        try {
            service.create(movement);
            redirectAttributes.addFlashAttribute(
                    "successMessage", "Movement created.");
        } catch (IllegalArgumentException exception) {
            bindingResult.reject("movement.invalid", exception.getMessage());
            addListData(model);
            return "movements/list";
        }
        return "redirect:/movements";
    }

    @PostMapping("/{id}/status")
    public String updateStatus(
            @PathVariable Long id,
            @RequestParam String status,
            RedirectAttributes redirectAttributes) {
        try {
            service.updateStatus(id, status);
            redirectAttributes.addFlashAttribute(
                    "successMessage", "Movement status updated.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute(
                    "errorMessage", exception.getMessage());
        }
        return "redirect:/movements";
    }

    private void addListData(Model model) {
        model.addAttribute("movements", service.findAll());
        model.addAttribute("vehicles", vehicleService.getAllVehicles());
        model.addAttribute("activeAllocations", allocationService.byStatus("Allocated"));
    }
}
