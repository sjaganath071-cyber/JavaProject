package com.team11.defense_logistics.controller;

import com.team11.defense_logistics.model.Maintenance;
import com.team11.defense_logistics.service.VehicleService;
import com.team11.defense_logistics.service.MaintenanceService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.validation.BindingResult;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/maintenance")
public class MaintenanceController {

    private final MaintenanceService maintenanceService;
    private final VehicleService vehicleService;

    public MaintenanceController(
            MaintenanceService maintenanceService,
            VehicleService vehicleService) {
        this.maintenanceService = maintenanceService;
        this.vehicleService = vehicleService;
    }

    @GetMapping
    public String listMaintenance(Model model) {
        model.addAttribute(
                "maintenanceRecords",
                maintenanceService.getAllRecords());

        return "maintenance/list";
    }

    @GetMapping("/new")
    public String newMaintenance(Model model) {
        Maintenance maintenance = new Maintenance();
        maintenance.setStatus("Pending");
        model.addAttribute("maintenance", maintenance);
        addFormOptions(model, "/maintenance");
        return "maintenance/form";
    }

    @PostMapping
    public String createMaintenance(
            @Valid @ModelAttribute("maintenance") Maintenance maintenance,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            addFormOptions(model, "/maintenance");
            return "maintenance/form";
        }
        try {
            maintenanceService.createRecord(maintenance);
        } catch (IllegalArgumentException exception) {
            bindingResult.reject("maintenance.invalid", exception.getMessage());
            addFormOptions(model, "/maintenance");
            return "maintenance/form";
        }
        redirectAttributes.addFlashAttribute(
                "successMessage", "Maintenance record created.");
        return "redirect:/maintenance";
    }

    @GetMapping("/edit/{id}")
    public String editMaintenance(@PathVariable Long id, Model model) {
        Maintenance maintenance = maintenanceService.getRecordById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Maintenance record not found"));
        model.addAttribute("maintenance", maintenance);
        addFormOptions(model, "/maintenance/update/" + id);
        return "maintenance/form";
    }

    @PostMapping("/update/{id}")
    public String updateMaintenance(
            @PathVariable Long id,
            @Valid @ModelAttribute("maintenance") Maintenance maintenance,
            BindingResult bindingResult,
            Model model,
            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            addFormOptions(model, "/maintenance/update/" + id);
            return "maintenance/form";
        }
        try {
            maintenanceService.updateRecord(id, maintenance);
        } catch (IllegalArgumentException exception) {
            bindingResult.reject("maintenance.invalid", exception.getMessage());
            addFormOptions(model, "/maintenance/update/" + id);
            return "maintenance/form";
        }
        redirectAttributes.addFlashAttribute(
                "successMessage", "Maintenance record updated.");
        return "redirect:/maintenance";
    }

    @PostMapping("/status/{id}")
    public String updateStatus(
            @PathVariable Long id,
            @RequestParam String status,
            RedirectAttributes redirectAttributes) {
        try {
            maintenanceService.updateStatus(id, status);
            redirectAttributes.addFlashAttribute(
                    "successMessage", "Maintenance status updated.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute(
                    "errorMessage", exception.getMessage());
        }
        return "redirect:/maintenance";
    }

    @PostMapping("/delete/{id}")
    public String deleteMaintenance(
            @PathVariable Long id,
            RedirectAttributes redirectAttributes) {
        try {
            maintenanceService.deleteRecord(id);
            redirectAttributes.addFlashAttribute(
                    "successMessage", "Maintenance record deleted.");
        } catch (IllegalArgumentException exception) {
            redirectAttributes.addFlashAttribute(
                    "errorMessage", exception.getMessage());
        }
        return "redirect:/maintenance";
    }

    private void addFormOptions(Model model, String formAction) {
        model.addAttribute("vehicles", vehicleService.getAllVehicles());
        model.addAttribute("formAction", formAction);
    }
}